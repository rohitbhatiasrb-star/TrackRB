package com.trackrb.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title;
    SharedPreferences sp;
    float den;
    Uri photoUri;
    long finalApprovalId;
    int cameraRequest=101, finalRequest=102;
    final int blue=Color.rgb(25,118,210), dark=Color.rgb(45,45,45), muted=Color.rgb(95,95,95), bg=Color.rgb(247,248,250);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(blue);
        den=getResources().getDisplayMetrics().density;
        sp=getSharedPreferences("trackrb",0);
        requestNotification();
        showDashboard();
    }
    void requestNotification(){
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},900);
    }
    int dp(int v){return (int)(v*den+0.5f);}
    TextView tv(String s,float size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        t.setPadding(dp(16),dp(10),dp(16),dp(10)); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(14); b.setMinHeight(dp(48)); b.setAllCaps(false); return b;
    }
    EditText edit(String hint){
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setSingleLine(false);
        e.setTextSize(16);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        e.setPadding(dp(14),dp(10),dp(14),dp(10));
        return e;
    }

    void base(String name){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        title=tv("TrackRB  •  "+name,20); title.setTextColor(Color.WHITE); title.setBackgroundColor(blue); title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(58)));
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(8),dp(8),dp(8),dp(8)); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void nav(){
        LinearLayout n=new LinearLayout(this); n.setPadding(dp(4),dp(3),dp(4),dp(3));
        String[] a={"Dashboard","New Approval","To-Do","Follow-ups"};
        for(String x:a){Button b=btn(x); b.setTextSize(13); b.setOnClickListener(v->{if(x.equals("Dashboard"))showDashboard();else if(x.equals("New Approval"))showApproval();else if(x.equals("To-Do"))showTodo();else showFollowups();}); n.addView(b,new LinearLayout.LayoutParams(0,dp(54),1));}
        root.addView(n);
    }
    JSONArray arr(String key){try{return new JSONArray(sp.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
    void save(String key,JSONArray a){sp.edit().putString(key,a.toString()).apply();}
    int count(String key,boolean done){JSONArray a=arr(key);int n=0;for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null&&a.optJSONObject(i).optBoolean("done")==done)n++;return n;}
    int pending(){JSONArray a=arr("approvals");int n=0;for(int i=0;i<a.length();i++)if(!a.optJSONObject(i).optBoolean("closed"))n++;return n;}
    int closed(){JSONArray a=arr("approvals");int n=0;for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optBoolean("closed"))n++;return n;}
    int followDue(){JSONArray a=arr("followups");int n=0;for(int i=0;i<a.length();i++)if(!a.optJSONObject(i).optBoolean("done"))n++;return n;}

    TextView stat(String label,String value,View.OnClickListener l){
        TextView t=tv(label+"\n"+value,17); t.setTypeface(null,1); t.setBackgroundColor(Color.WHITE); t.setOnClickListener(l);
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(78))); Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(7))); return t;
    }
    void showDashboard(){
        base("Dashboard");
        TextView h=tv("APPROVAL PENDENCY",19);h.setTypeface(null,1);content.addView(h);
        content.addView(tv("Tap a summary to open its records.",14));
        stat("Pending approvals",String.valueOf(pending()),v->showApprovalList(false));
        stat("Due / overdue follow-ups",String.valueOf(followDue()),v->showFollowupList());
        stat("Today's To-Do",String.valueOf(count("todos",false)),v->showTodoList());
        stat("Closed approvals",String.valueOf(closed()),v->showApprovalList(true));
        Button b=btn("＋  ADD NEW APPROVAL");b.setOnClickListener(v->showApproval());content.addView(b);
        Button t=btn("＋  ADD TODAY'S TO-DO");t.setOnClickListener(v->showTodo());content.addView(t);nav();
    }

    void showApproval(){
        base("New Approval");
        EditText subject=edit("Approval subject / description");
        EditText from=edit("Received from / department");
        TextView due=tv("Due date: Not selected",15); Button dueBtn=btn("SELECT DUE DATE");
        final String[] dueValue={""}; dueBtn.setOnClickListener(v->pickDate(due,dueValue));
        content.addView(tv("Received automatically: "+now(),15));content.addView(subject);content.addView(from);content.addView(dueBtn);content.addView(due);
        TextView photo=tv("Front paper: Not attached",14);Button cam=btn("📷  SCAN FRONT PAPER");cam.setOnClickListener(v->camera(photo));content.addView(cam);content.addView(photo);
        Button save=btn("SAVE APPROVAL");save.setOnClickListener(v->{
            if(subject.getText().toString().trim().isEmpty()){subject.setError("Required");return;}
            try{JSONArray a=arr("approvals");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("subject",subject.getText().toString().trim());o.put("from",from.getText().toString().trim());o.put("due",dueValue[0]);o.put("received",now());o.put("scan",photoUri==null?"":photoUri.toString());o.put("closed",false);o.put("final","");o.put("closedAt","");a.put(o);save("approvals",a);photoUri=null;Toast.makeText(this,"Approval saved",Toast.LENGTH_SHORT).show();showApprovalList(false);
            }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
        });content.addView(save);nav();
    }
    void pickDate(TextView target,String[] value){
        Calendar c=Calendar.getInstance(); DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{String s=String.format(Locale.getDefault(),"%02d-%02d-%04d",day,m+1,y);value[0]=s;target.setText("Due date: "+s);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));d.show();
    }
    void pickDateTime(TextView target,String[] value){
        Calendar c=Calendar.getInstance(); DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{TimePickerDialog td=new TimePickerDialog(this,(tv,h,min)->{String s=String.format(Locale.getDefault(),"%02d-%02d-%04d %02d:%02d",day,m+1,y,h,min);value[0]=s;target.setText("Due: "+s);},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true);td.show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));d.show();
    }
    void camera(TextView label){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},cameraRequest);return;}
        try{File dir=new File(getFilesDir(),"images");dir.mkdirs();File f=new File(dir,"approval_"+System.currentTimeMillis()+".jpg");photoUri=FileProvider.getUriForFile(this,"com.trackrb.app.fileprovider",f);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,200);label.setText("Front paper: Camera opened");}
        catch(Exception e){Toast.makeText(this,"Camera could not open: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    @Override public void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==200&&c==RESULT_OK){Toast.makeText(this,"Front paper captured",Toast.LENGTH_SHORT).show();}
        else if(r==finalRequest&&c==RESULT_OK&&d!=null&&d.getData()!=null){
            try{Uri u=d.getData(); if((d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0)try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                JSONArray a=arr("approvals");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optLong("id")==finalApprovalId){o.put("final",u.toString());o.put("closed",true);o.put("closedAt",now());break;}}save("approvals",a);Toast.makeText(this,"Approval closed",Toast.LENGTH_SHORT).show();showApprovalList(false);
            }catch(Exception e){Toast.makeText(this,"Could not attach copy",Toast.LENGTH_LONG).show();}
        }
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);}

    boolean isPdf(String uri){return uri!=null&&uri.toLowerCase(Locale.ROOT).contains("pdf");}
    void openAttachment(String uri){
        if(uri==null||uri.trim().isEmpty())return;
        if(isPdf(uri)){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(uri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){Toast.makeText(this,"No PDF viewer available",Toast.LENGTH_SHORT).show();}}
        else showFullImage(uri);
    }
    ImageView imagePreview(String uri){ImageView im=new ImageView(this);im.setAdjustViewBounds(true);im.setScaleType(ImageView.ScaleType.FIT_CENTER);im.setPadding(dp(8),dp(8),dp(8),dp(8));im.setBackgroundColor(Color.WHITE);try{im.setImageURI(Uri.parse(uri));}catch(Exception ignored){}return im;}
    void showFullImage(String uri){
        try{Dialog d=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setBackgroundColor(Color.WHITE);ImageView im=imagePreview(uri);box.addView(im,new LinearLayout.LayoutParams(-1,0,1));Button close=btn("CLOSE");close.setOnClickListener(v->d.dismiss());box.addView(close);d.setContentView(box);d.show();if(d.getWindow()!=null)d.getWindow().setLayout(-1,-1);}
        catch(Exception e){Toast.makeText(this,"Could not open attachment",Toast.LENGTH_SHORT).show();}
    }

    TextView cell(String text, boolean header){
        TextView t=new TextView(this);
        t.setText(text);
        t.setTextSize(header?13:12);
        t.setTextColor(header?Color.WHITE:dark);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(10),dp(9),dp(10),dp(9));
        if(header){
            t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            t.setBackgroundColor(blue);
        }else{
            t.setBackgroundColor(Color.WHITE);
        }
        return t;
    }

    void addApprovalTableRow(TableLayout table, JSONObject o, boolean closedView, int serial){
        TableRow row=new TableRow(this);
        row.setClickable(true);
        row.setBackgroundColor(Color.WHITE);
        String subject=blank(o.optString("subject"));
        String from=blank(o.optString("from"));
        String received=blank(o.optString("received"));
        String due=o.optString("due").isEmpty()?"Not set":o.optString("due");
        String status=closedView?"CLOSED":"PENDING";

        row.addView(cell(String.valueOf(serial),false),new TableRow.LayoutParams(dp(55),dp(62)));
        row.addView(cell(subject,false),new TableRow.LayoutParams(dp(230),dp(62)));
        row.addView(cell(from,false),new TableRow.LayoutParams(dp(140),dp(62)));
        row.addView(cell(received,false),new TableRow.LayoutParams(dp(145),dp(62)));
        row.addView(cell(due,false),new TableRow.LayoutParams(dp(120),dp(62)));
        TextView st=cell(status,true);
        st.setBackgroundColor(closedView?Color.rgb(46,125,50):Color.rgb(230,126,34));
        row.addView(st,new TableRow.LayoutParams(dp(105),dp(62)));

        long id=o.optLong("id");
        row.setOnClickListener(v->showApprovalDetail(id,closedView));
        table.addView(row,new TableLayout.LayoutParams(-2,-2));
        View divider=new View(this);
        divider.setBackgroundColor(Color.rgb(215,215,215));
        table.addView(divider,new TableLayout.LayoutParams(-1,dp(1)));
    }

    String blank(String s){return s==null||s.trim().isEmpty()?"—":s;}

    void showApprovalDetail(long id, boolean closedView){
        JSONObject found=null;
        JSONArray a=arr("approvals");
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optLong("id")==id){found=o;break;}}
        if(found==null)return;
        Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(16),dp(18),dp(12));box.setBackgroundColor(Color.WHITE);
        TextView h=tv(blank(found.optString("subject")),20);h.setTypeface(null,Typeface.BOLD);box.addView(h);
        box.addView(tv("From: "+blank(found.optString("from"))+"\nReceived: "+blank(found.optString("received"))+"\nDue: "+(found.optString("due").isEmpty()?"Not set":found.optString("due")),15));
        String scan=found.optString("scan");
        Button scanBtn=btn("VIEW FRONT SCAN");scanBtn.setEnabled(!scan.isEmpty());scanBtn.setOnClickListener(v->openAttachment(scan));box.addView(scanBtn);
        if(closedView){
            String fin=found.optString("final");
            Button finalBtn=btn("VIEW FINAL APPROVAL COPY");finalBtn.setEnabled(!fin.trim().isEmpty());finalBtn.setOnClickListener(v->openAttachment(fin));box.addView(finalBtn);
        }else{
            Button close=btn("CLOSE + ATTACH FINAL COPY");close.setOnClickListener(v->{d.dismiss();closeApproval(id);});box.addView(close);
        }
        Button cancel=btn("CLOSE");cancel.setOnClickListener(v->d.dismiss());box.addView(cancel);
        d.setContentView(box);d.show();
        if(d.getWindow()!=null){d.getWindow().setLayout(-1,-2);}
    }

    void showApprovalList(boolean wantClosed){
        base(wantClosed?"Closed Approvals":"Pending Approvals");

        EditText search=edit("Search subject, department, received or due date...");
        search.setSingleLine(true);
        search.setTextSize(14);
        content.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));

        TextView info=tv("TABLE VIEW  •  Tap any row for details & attachments",13);
        info.setTextColor(muted);
        content.addView(info);

        HorizontalScrollView hsv=new HorizontalScrollView(this);
        hsv.setFillViewport(false);
        TableLayout table=new TableLayout(this);
        table.setStretchAllColumns(false);
        table.setShrinkAllColumns(false);
        table.setBackgroundColor(Color.WHITE);

        TableRow header=new TableRow(this);
        String[] heads={"S.NO","SUBJECT / DESCRIPTION","FROM","RECEIVED","DUE","STATUS"};
        int[] widths={55,230,140,145,120,105};
        for(int i=0;i<heads.length;i++) header.addView(cell(heads[i],true),new TableRow.LayoutParams(dp(widths[i]),dp(52)));
        table.addView(header,new TableLayout.LayoutParams(-2,-2));
        hsv.addView(table);
        content.addView(hsv,new LinearLayout.LayoutParams(-1,0,1));

        Runnable[] refresh=new Runnable[1];
        refresh[0]=()->{
            while(table.getChildCount()>1)table.removeViewAt(1);
            String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            JSONArray a=arr("approvals");
            int shown=0,serial=1;
            for(int i=a.length()-1;i>=0;i--){
                JSONObject o=a.optJSONObject(i);
                if(o==null||o.optBoolean("closed")!=wantClosed)continue;
                String hay=(o.optString("subject")+" "+o.optString("from")+" "+o.optString("received")+" "+o.optString("due")).toLowerCase(Locale.ROOT);
                if(!q.isEmpty()&&!hay.contains(q))continue;
                shown++;addApprovalTableRow(table,o,wantClosed,serial++);
            }
            if(shown==0){
                TableRow empty=new TableRow(this);
                TextView e=cell(q.isEmpty()?"No records here.":"No matching records.",false);
                empty.addView(e,new TableRow.LayoutParams(dp(795),dp(58)));
                table.addView(empty,new TableLayout.LayoutParams(-2,-2));
            }
        };
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){refresh[0].run();}
            public void afterTextChanged(Editable e){}
        });
        refresh[0].run();

        Button back=btn("←  Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();
    }

    void closeApproval(long id){
        finalApprovalId=id;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","application/pdf"});i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);i.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(i,finalRequest);}catch(Exception e){markClosed(id,"");}
    }
    void markClosed(long id,String finalUri){try{JSONArray a=arr("approvals");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id){a.getJSONObject(i).put("closed",true);a.getJSONObject(i).put("final",finalUri==null?"":finalUri);a.getJSONObject(i).put("closedAt",now());break;}save("approvals",a);showApprovalList(false);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}

    void showTodo(){
        base("Today's To-Do");EditText task=edit("What needs to be done?");EditText who=edit("Whom / person");TextView when=tv("Due: Not selected",15);String[] whenValue={""};Button pick=btn("SELECT DATE & TIME");pick.setOnClickListener(v->pickDateTime(when,whenValue));content.addView(task);content.addView(who);content.addView(pick);content.addView(when);
        Button add=btn("SAVE TO-DO");add.setOnClickListener(v->{if(task.getText().toString().trim().isEmpty()){task.setError("Required");return;}try{JSONArray a=arr("todos");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("task",task.getText().toString().trim());o.put("who",who.getText().toString().trim());o.put("when",whenValue[0]);o.put("created",now());o.put("done",false);o.put("doneAt","");a.put(o);save("todos",a);showTodoList();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});content.addView(add);Button list=btn("VIEW TO-DO LIST / HISTORY");list.setOnClickListener(v->showTodoList());content.addView(list);nav();
    }
    void showTodoList(){
        base("To-Do List / History");JSONArray a=arr("todos");int n=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;n++;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundColor(Color.WHITE);c.addView(tv((o.optBoolean("done")?"✓  ":"•  ")+o.optString("task"),18));c.addView(tv("Whom: "+blank(o.optString("who"))+"\nDue: "+blank(o.optString("when"))+"\nCreated: "+o.optString("created")+(o.optBoolean("done")?"\nClosed: "+blank(o.optString("doneAt")):""),14));if(!o.optBoolean("done")){long id=o.optLong("id");Button d=btn("MARK CLOSED");d.setOnClickListener(v->todoDone(id));c.addView(d);}content.addView(c,new LinearLayout.LayoutParams(-1,-2));Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(9)));}if(n==0)content.addView(tv("No To-Do records.",17));Button back=btn("←  Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();
    }
    void todoDone(long id){try{JSONArray a=arr("todos");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id){a.getJSONObject(i).put("done",true);a.getJSONObject(i).put("doneAt",now());}save("todos",a);showTodoList();}catch(Exception e){}}

    void showFollowups(){
        base("Follow-ups");EditText what=edit("What to follow up?");EditText whom=edit("Whom to ask?");TextView date=tv("Due: Not selected",15);String[] dateValue={""};Button pick=btn("SELECT DATE & TIME");pick.setOnClickListener(v->pickDateTime(date,dateValue));content.addView(what);content.addView(whom);content.addView(pick);content.addView(date);
        Button add=btn("SAVE FOLLOW-UP");add.setOnClickListener(v->{if(what.getText().toString().trim().isEmpty()){what.setError("Required");return;}try{JSONArray a=arr("followups");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("what",what.getText().toString().trim());o.put("whom",whom.getText().toString().trim());o.put("date",dateValue[0]);o.put("created",now());o.put("done",false);o.put("doneAt","");a.put(o);save("followups",a);showFollowupList();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});content.addView(add);Button list=btn("VIEW FOLLOW-UP HISTORY");list.setOnClickListener(v->showFollowupList());content.addView(list);nav();
    }
    void showFollowupList(){
        base("Follow-up History");JSONArray a=arr("followups");int n=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;n++;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundColor(Color.WHITE);c.addView(tv((o.optBoolean("done")?"✓  ":"•  ")+o.optString("what"),18));c.addView(tv("Whom: "+blank(o.optString("whom"))+"\nDue: "+blank(o.optString("date"))+"\nCreated: "+o.optString("created")+(o.optBoolean("done")?"\nCompleted: "+blank(o.optString("doneAt")):""),14));if(!o.optBoolean("done")){long id=o.optLong("id");Button d=btn("MARK DONE");d.setOnClickListener(v->followDone(id));c.addView(d);}content.addView(c,new LinearLayout.LayoutParams(-1,-2));Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(9)));}if(n==0)content.addView(tv("No follow-up records.",17));Button back=btn("←  Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();
    }
    void followDone(long id){try{JSONArray a=arr("followups");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id){a.getJSONObject(i).put("done",true);a.getJSONObject(i).put("doneAt",now());}save("followups",a);showFollowupList();}catch(Exception e){}}
    String now(){return new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date());}
}
