package com.trackrb.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title;
    SharedPreferences sp;
    float den;
    Uri photoUri;
    Uri finalPhotoUri;
    String photoFilePath="";
    String finalPhotoFilePath="";
    long finalApprovalId;
    int cameraRequest=101, finalRequest=102, exportRequest=103;
    String exportMode="";
    final int blue=Color.rgb(25,118,210), dark=Color.rgb(45,45,45), muted=Color.rgb(95,95,95), bg=Color.rgb(247,248,250);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(blue);
        den=getResources().getDisplayMetrics().density;
        sp=getSharedPreferences("trackrb",0);
        requestNotification();
        showDashboard();
    }
    void requestNotification(){
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},900);
    }
    int dp(int v){return (int)(v*den+0.5f);}
    TextView tv(String s,float size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        t.setPadding(dp(16),dp(10),dp(16),dp(10)); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(14); b.setMinHeight(dp(48)); b.setAllCaps(false); return b;
    }
    EditText edit(String hint){
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setSingleLine(false);
        e.setTextSize(16);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        e.setPadding(dp(14),dp(10),dp(14),dp(10));
        return e;
    }

    void base(String name){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        title=tv("TrackRB  •  "+name,20); title.setTextColor(Color.WHITE); title.setBackgroundColor(blue); title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(58)));
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(8),dp(8),dp(8),dp(8)); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void nav(){
        LinearLayout n=new LinearLayout(this); n.setPadding(dp(4),dp(3),dp(4),dp(3));
        String[] a={"Dashboard","New Approval","To-Do","Follow-ups"};
        for(String x:a){Button b=btn(x); b.setTextSize(13); b.setOnClickListener(v->{if(x.equals("Dashboard"))showDashboard();else if(x.equals("New Approval"))showApproval();else if(x.equals("To-Do"))showTodo();else showFollowups();}); n.addView(b,new LinearLayout.LayoutParams(0,dp(54),1));}
        root.addView(n);
    }
    JSONArray arr(String key){try{return new JSONArray(sp.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
    void save(String key,JSONArray a){sp.edit().putString(key,a.toString()).apply();}
    int count(String key,boolean done){JSONArray a=arr(key);int n=0;for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null&&a.optJSONObject(i).optBoolean("done")==done)n++;return n;}
    int pending(){JSONArray a=arr("approvals");int n=0;for(int i=0;i<a.length();i++)if(!a.optJSONObject(i).optBoolean("closed"))n++;return n;}
    int closed(){JSONArray a=arr("approvals");int n=0;for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optBoolean("closed"))n++;return n;}
    int followDue(){JSONArray a=arr("followups");int n=0;for(int i=0;i<a.length();i++)if(!a.optJSONObject(i).optBoolean("done"))n++;return n;}

    TextView stat(String label,String value,View.OnClickListener l){
        TextView t=tv(label+"\n"+value,17); t.setTypeface(null,1); t.setBackgroundColor(Color.WHITE); t.setOnClickListener(l);
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(78))); Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(7))); return t;
    }
    void showDashboard(){
        base("Dashboard");
        TextView h=tv("APPROVAL PENDENCY",19);h.setTypeface(null,1);content.addView(h);
        content.addView(tv("Tap a summary to open its records.",14));
        stat("Pending approvals",String.valueOf(pending()),v->showApprovalList(false));
        stat("Due / overdue follow-ups",String.valueOf(followDue()),v->showFollowupList());
        stat("Today's To-Do",String.valueOf(count("todos",false)),v->showTodoList());
        stat("Closed approvals",String.valueOf(closed()),v->showApprovalList(true));
        Button b=btn("＋  ADD NEW APPROVAL");b.setOnClickListener(v->showApproval());content.addView(b);
        Button t=btn("＋  ADD TODAY'S TO-DO");t.setOnClickListener(v->showTodo());content.addView(t);nav();
    }

    void showApproval(){
        base("New Approval");
        EditText subject=edit("Approval subject / description");
        EditText from=edit("Received from / department");
        TextView due=tv("Due date: Not selected",15); Button dueBtn=btn("SELECT DUE DATE");
        final String[] dueValue={""}; dueBtn.setOnClickListener(v->pickDate(due,dueValue));
        content.addView(tv("Received automatically: "+now(),15));content.addView(subject);content.addView(from);content.addView(dueBtn);content.addView(due);
        TextView photo=tv("Front paper: Not attached",14);Button cam=btn("📷  SCAN FRONT PAPER");cam.setOnClickListener(v->camera(photo));content.addView(cam);content.addView(photo);
        Button save=btn("SAVE APPROVAL");save.setOnClickListener(v->{
            if(subject.getText().toString().trim().isEmpty()){subject.setError("Required");return;}
            try{JSONArray a=arr("approvals");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("subject",capFirst(subject.getText().toString().trim()));o.put("from",capFirst(from.getText().toString().trim()));o.put("due",dueValue[0]);o.put("received",now());o.put("scan",photoUri==null?"":photoUri.toString());o.put("closed",false);o.put("final","");o.put("closedAt","");o.put("stage",1);o.put("level2Date","");o.put("level3Date","");o.put("finalUpdateDate","");o.put("finalUpdate","");o.put("returned",false);o.put("returnReason","");o.put("returnedAt","");o.put("receivedBackAt","");o.put("receivedBackReason","");o.put("givenTo2","");o.put("givenTo3","");o.put("approvedTo","");o.put("history",new JSONArray());addHistory(o,"Received at first level",o.optString("received"),"");a.put(o);save("approvals",a);photoUri=null;photoFilePath="";Toast.makeText(this,"Approval saved",Toast.LENGTH_SHORT).show();showApprovalList(false);
            }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
        });content.addView(save);nav();
    }
    void pickDate(TextView target,String[] value){
        Calendar c=Calendar.getInstance(); DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{String s=String.format(Locale.getDefault(),"%02d-%02d-%04d",day,m+1,y);value[0]=s;target.setText("Due date: "+s);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));d.show();
    }
    void pickDateTime(TextView target,String[] value){
        Calendar c=Calendar.getInstance(); DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{TimePickerDialog td=new TimePickerDialog(this,(tv,h,min)->{String s=String.format(Locale.getDefault(),"%02d-%02d-%04d %02d:%02d",day,m+1,y,h,min);value[0]=s;target.setText("Due: "+s);},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true);td.show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));d.show();
    }
    void camera(TextView label){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},cameraRequest);return;}
        try{File dir=new File(getFilesDir(),"images");dir.mkdirs();File f=new File(dir,"approval_"+System.currentTimeMillis()+".jpg");photoFilePath=f.getAbsolutePath();photoUri=FileProvider.getUriForFile(this,"com.trackrb.app.fileprovider",f);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,200);label.setText("Front paper: Camera opened");}
        catch(Exception e){Toast.makeText(this,"Camera could not open: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    void compressImageFile(File file){
        try{Bitmap src=BitmapFactory.decodeFile(file.getAbsolutePath());if(src==null)return;int max=1600;float scale=Math.min(1f,Math.min((float)max/src.getWidth(),(float)max/src.getHeight()));Bitmap out=src;if(scale<1f)out=Bitmap.createScaledBitmap(src,Math.round(src.getWidth()*scale),Math.round(src.getHeight()*scale),true);File tmp=new File(file.getParent(),file.getName()+".tmp");FileOutputStream fos=new FileOutputStream(tmp);out.compress(Bitmap.CompressFormat.JPEG,65,fos);fos.flush();fos.close();if(out!=src)out.recycle();src.recycle();if(file.delete())tmp.renameTo(file);}
        catch(Exception ignored){}
    }

    @Override public void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==200&&c==RESULT_OK){try{if(!photoFilePath.isEmpty()){compressImageFile(new File(photoFilePath));}}catch(Exception ignored){}Toast.makeText(this,"Front paper captured (compressed)",Toast.LENGTH_SHORT).show();}
        else if(r==finalRequest&&c==RESULT_OK){
            try{
                if(finalPhotoUri==null)throw new Exception("Final photo not available");
                try{if(!finalPhotoFilePath.isEmpty())compressImageFile(new File(finalPhotoFilePath));}catch(Exception ignored){}
                JSONArray a=arr("approvals");
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i);
                    if(o.optLong("id")==finalApprovalId){
                        o.put("final",finalPhotoUri.toString());
                        o.put("closed",true);
                        o.put("closedAt",now());
                        break;
                    }
                }
                save("approvals",a);
                finalPhotoUri=null;finalPhotoFilePath="";
                Toast.makeText(this,"Final photo captured and approval closed",Toast.LENGTH_SHORT).show();
                showApprovalList(false);
            }catch(Exception e){Toast.makeText(this,"Could not capture final photo: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        else if(r==exportRequest&&c==RESULT_OK&&d!=null&&d.getData()!=null){
            try{
                Uri u=d.getData();
                OutputStream out=getContentResolver().openOutputStream(u);
                if(out==null)throw new Exception("Cannot open export file");
                StringBuilder csv=new StringBuilder();
                csv.append("S.No,Subject / Description,From,Received,Due,Status,Stage,2nd Level Date,3rd Level Date,Final Update Date,Final Update,Return Reason,Returned At,Received Back At\n");
                JSONArray a=arr("approvals"); int serial=1;
                for(int i=a.length()-1;i>=0;i--){
                    JSONObject o=a.optJSONObject(i); if(o==null)continue;
                    boolean include=false;
                    if("pending".equals(exportMode)) include=!o.optBoolean("closed");
                    else if("approved".equals(exportMode)) include=o.optBoolean("closed");
                    else if("level2".equals(exportMode)) include=!o.optBoolean("closed")&&o.optInt("stage",1)==2;
                    if(!include)continue;
                    String status=o.optBoolean("closed")?"APPROVED":(o.optBoolean("returned")?"RETURNED":"PENDING");
                    String stage=stageLabel(o.optInt("stage",1));
                    csv.append(csvCell(String.valueOf(serial++))).append(',')
                       .append(csvCell(o.optString("subject"))).append(',')
                       .append(csvCell(o.optString("from"))).append(',')
                       .append(csvCell(o.optString("received"))).append(',')
                       .append(csvCell(o.optString("due"))).append(',')
                       .append(csvCell(status)).append(',')
                       .append(csvCell(stage)).append(',')
                       .append(csvCell(o.optString("level2Date"))).append(',')
                       .append(csvCell(o.optString("level3Date"))).append(',')
                       .append(csvCell(o.optString("finalUpdateDate"))).append(',')
                       .append(csvCell(o.optString("finalUpdate"))).append(',')
                       .append(csvCell(o.optString("returnReason"))).append(',')
                       .append(csvCell(o.optString("returnedAt"))).append(',')
                       .append(csvCell(o.optString("receivedBackAt"))).append('\n');
                }
                out.write(new byte[]{(byte)0xEF,(byte)0xBB,(byte)0xBF});
                out.write(csv.toString().getBytes("UTF-8")); out.close();
                Toast.makeText(this,"Excel-compatible CSV exported",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);}

    boolean isPdf(String uri){return uri!=null&&uri.toLowerCase(Locale.ROOT).contains("pdf");}
    void openAttachment(String uri){
        if(uri==null||uri.trim().isEmpty())return;
        if(isPdf(uri)){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(uri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){Toast.makeText(this,"No PDF viewer available",Toast.LENGTH_SHORT).show();}}
        else showFullImage(uri);
    }
    ImageView imagePreview(String uri){ImageView im=new ImageView(this);im.setAdjustViewBounds(true);im.setScaleType(ImageView.ScaleType.FIT_CENTER);im.setPadding(dp(8),dp(8),dp(8),dp(8));im.setBackgroundColor(Color.WHITE);try{im.setImageURI(Uri.parse(uri));}catch(Exception ignored){}return im;}
    void showFullImage(String uri){
        try{Dialog d=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setBackgroundColor(Color.WHITE);ImageView im=imagePreview(uri);box.addView(im,new LinearLayout.LayoutParams(-1,0,1));Button close=btn("CLOSE");close.setOnClickListener(v->d.dismiss());box.addView(close);d.setContentView(box);d.show();if(d.getWindow()!=null)d.getWindow().setLayout(-1,-1);}
        catch(Exception e){Toast.makeText(this,"Could not open attachment",Toast.LENGTH_SHORT).show();}
    }

    TextView cell(String text, boolean header){
        TextView t=new TextView(this);
        t.setText(text);
        t.setTextSize(header?13:12);
        t.setTextColor(header?Color.WHITE:dark);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(10),dp(9),dp(10),dp(9));
        if(header){
            t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            t.setBackgroundColor(blue);
        }else{
            t.setBackgroundColor(Color.WHITE);
        }
        return t;
    }

    void addApprovalTableRow(TableLayout table, JSONObject o, boolean closedView, int serial){
        TableRow row=new TableRow(this);
        row.setClickable(true);
        row.setBackgroundColor(Color.WHITE);
        String subject=blank(o.optString("subject"));
        String from=blank(o.optString("from"));
        String received=blank(o.optString("received"));
        String due=o.optString("due").isEmpty()?"Not set":o.optString("due");
        String status=closedView?"CLOSED":(o.optBoolean("returned")?"RETURNED":"PENDING");

        row.addView(cell(String.valueOf(serial),false),new TableRow.LayoutParams(dp(55),dp(62)));
        row.addView(cell(subject,false),new TableRow.LayoutParams(dp(230),dp(62)));
        row.addView(cell(from,false),new TableRow.LayoutParams(dp(140),dp(62)));
        row.addView(cell(received,false),new TableRow.LayoutParams(dp(145),dp(62)));
        row.addView(cell(due,false),new TableRow.LayoutParams(dp(120),dp(62)));
        TextView st=cell(status,true);
        st.setBackgroundColor(closedView?Color.rgb(46,125,50):(o.optBoolean("returned")?Color.rgb(156,39,176):Color.rgb(230,126,34)));
        row.addView(st,new TableRow.LayoutParams(dp(105),dp(62)));

        long id=o.optLong("id");
        row.setOnClickListener(v->showApprovalDetail(id,closedView));
        table.addView(row,new TableLayout.LayoutParams(-2,-2));
        View divider=new View(this);
        divider.setBackgroundColor(Color.rgb(215,215,215));
        table.addView(divider,new TableLayout.LayoutParams(-1,dp(1)));
    }

    String blank(String s){return s==null||s.trim().isEmpty()?"—":s;}

    void addHistory(JSONObject o,String event,String date,String note){
        try{JSONArray h=o.optJSONArray("history");if(h==null)h=new JSONArray();JSONObject e=new JSONObject();e.put("event",event);e.put("date",date==null?now():date);e.put("note",note==null?"":note);h.put(e);o.put("history",h);}catch(Exception ignored){}
    }
    void addMovementHistoryTable(LinearLayout box, JSONObject o){
        box.addView(tv("COMPLETE MOVEMENT HISTORY",16));
        TableLayout table=new TableLayout(this); table.setStretchAllColumns(false); table.setBackgroundColor(Color.WHITE);
        TableRow head=new TableRow(this);
        String[] hs={"DATE / TIME","MOVEMENT / ACTION","USER / REMARKS"};
        int[] hw={145,210,220};
        for(int i=0;i<hs.length;i++) head.addView(cell(hs[i],true),new TableRow.LayoutParams(dp(hw[i]),dp(48)));
        table.addView(head);
        JSONArray h=o.optJSONArray("history");
        if(h!=null){
            for(int i=0;i<h.length();i++){
                JSONObject e=h.optJSONObject(i); if(e==null) continue;
                TableRow r=new TableRow(this);
                r.addView(cell(blank(e.optString("date")),false),new TableRow.LayoutParams(dp(145),dp(58)));
                r.addView(cell(blank(e.optString("event")),false),new TableRow.LayoutParams(dp(210),dp(58)));
                r.addView(cell(blank(e.optString("note")),false),new TableRow.LayoutParams(dp(220),dp(58)));
                table.addView(r);
                View line=new View(this); line.setBackgroundColor(Color.rgb(220,220,220)); table.addView(line,new TableLayout.LayoutParams(-1,dp(1)));
            }
        }
        HorizontalScrollView scroll=new HorizontalScrollView(this); scroll.addView(table); box.addView(scroll,new LinearLayout.LayoutParams(-1,dp(190)));
    }

    String stageText(JSONObject o){
        int stage=o.optInt("stage",1);
        StringBuilder b=new StringBuilder();
        b.append("Stage: ").append(stageLabel(stage));
        if(!o.optString("givenTo2").trim().isEmpty())b.append("\n2nd level user: ").append(o.optString("givenTo2"));
        if(!o.optString("level2Date").trim().isEmpty())b.append("\nGiven to 2nd level: ").append(o.optString("level2Date"));
        if(!o.optString("givenTo3").trim().isEmpty())b.append("\n3rd level user: ").append(o.optString("givenTo3"));
        if(!o.optString("level3Date").trim().isEmpty())b.append("\nGiven to 3rd level: ").append(o.optString("level3Date"));
        if(!o.optString("approvedTo").trim().isEmpty())b.append("\nApproved / sent to: ").append(o.optString("approvedTo"));
        if(!o.optString("returnedAt").trim().isEmpty()){
            b.append("\nLast returned on: ").append(o.optString("returnedAt"));
            b.append("\nReturn reason: ").append(blank(o.optString("returnReason")));
        }
        if(!o.optString("receivedBackAt").trim().isEmpty()){
            b.append("\nReceived back on: ").append(o.optString("receivedBackAt"));
            b.append("\nReceived-back update/reason: ").append(blank(o.optString("receivedBackReason")));
        }
        b.append(historyText(o));
        return b.toString();
    }

    void advanceApproval(long id,int nextStage){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),dp(2));
        EditText person=edit(nextStage==2?"2nd level user name (optional)":"3rd level user name (optional)");
        box.addView(person);
        new AlertDialog.Builder(this).setTitle(nextStage==2?"Send to 2nd Level":"Send to 3rd Level").setView(box)
            .setPositiveButton("SELECT DATE",(dialog,which)->{
                Calendar c=Calendar.getInstance();
                DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{
                    String date=String.format(Locale.getDefault(),"%02d-%02d-%04d",day,m+1,y);
                    try{
                        JSONArray a=arr("approvals");
                        for(int i=0;i<a.length();i++){
                            JSONObject o=a.getJSONObject(i);
                            if(o.optLong("id")==id){
                                o.put("stage",nextStage);
                                String personName=capFirst(person.getText().toString().trim());
                                if(nextStage==2){o.put("level2Date",date);o.put("givenTo2",personName);}
                                if(nextStage==3){o.put("level3Date",date);o.put("givenTo3",personName);}
                                addHistory(o,nextStage==2?"Given to 2nd level":"Given to 3rd level",date,personName);
                                break;
                            }
                        }
                        save("approvals",a);Toast.makeText(this,"Stage updated",Toast.LENGTH_SHORT).show();showApprovalDetail(id,false);
                    }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
                },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));d.show();
            }).setNegativeButton("CANCEL",null).show();
    }

    void markReturned(long id){
        final EditText reason=edit("Reason for return (required)");
        new AlertDialog.Builder(this).setTitle("Return to Sender").setView(reason)
            .setPositiveButton("MARK RETURNED",(dialog,which)->{
                String r=reason.getText().toString().trim();
                if(r.isEmpty()){Toast.makeText(this,"Return reason is required",Toast.LENGTH_SHORT).show();return;}
                try{
                    JSONArray a=arr("approvals");
                    for(int i=0;i<a.length();i++){
                        JSONObject o=a.getJSONObject(i);
                        if(o.optLong("id")==id){o.put("returned",true);o.put("returnReason",r);o.put("returnedAt",now());addHistory(o,"Returned from "+stageLabel(o.optInt("stage",1)),o.optString("returnedAt"),r);break;}
                    }
                    save("approvals",a); Toast.makeText(this,"Marked as returned",Toast.LENGTH_SHORT).show(); showApprovalDetail(id,false);
                }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
            }).setNegativeButton("CANCEL",null).show();
    }

    void receiveBack(long id){
        EditText update=edit("What update/reason was received back? (optional)");
        new AlertDialog.Builder(this).setTitle("Receive Back").setView(update)
            .setPositiveButton("SAVE",(dialog,which)->{
                try{
                    JSONArray a=arr("approvals");
                    for(int i=0;i<a.length();i++){
                        JSONObject o=a.getJSONObject(i);
                        if(o.optLong("id")==id){
                            String t=capFirst(update.getText().toString().trim());
                            o.put("returned",false);o.put("receivedBackAt",now());o.put("receivedBackReason",t);
                            addHistory(o,"Received back after return",o.optString("receivedBackAt"),t);break;
                        }
                    }
                    save("approvals",a);Toast.makeText(this,"Received-back details saved",Toast.LENGTH_SHORT).show();showApprovalDetail(id,false);
                }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
            }).setNegativeButton("CANCEL",null).show();
    }

    void recordFinalUpdate(long id){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(12),dp(20),dp(4));
        EditText remarks=edit("Final update / remarks received from 3rd level");
        EditText approvedTo=edit("Approved / sent to user name (optional)");
        box.addView(remarks);box.addView(approvedTo);
        new AlertDialog.Builder(this).setTitle("Record Final Update").setView(box).setPositiveButton("SELECT DATE",(dialog,which)->{
            Calendar c=Calendar.getInstance();
            DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{
                String date=String.format(Locale.getDefault(),"%02d-%02d-%04d",day,m+1,y);
                try{
                    JSONArray a=arr("approvals");
                    for(int i=0;i<a.length();i++){
                        JSONObject o=a.getJSONObject(i);
                        if(o.optLong("id")==id){
                            String remarkText=capFirst(remarks.getText().toString().trim());
                            String sentUser=capFirst(approvedTo.getText().toString().trim());
                            if(remarkText.isEmpty() || sentUser.isEmpty()){
                                Toast.makeText(this,"Final update and Approved/Sent-to user name are mandatory",Toast.LENGTH_LONG).show();
                                return;
                            }
                            o.put("stage",4);o.put("finalUpdateDate",date);o.put("finalUpdate",remarkText);o.put("approvedTo",sentUser);
                            addHistory(o,"Final update received",date,remarkText);
                            addHistory(o,"Approved / sent to",date,sentUser);
                            break;
                        }
                    }
                    save("approvals",a);
                    Toast.makeText(this,"Final update saved",Toast.LENGTH_SHORT).show();
                    showApprovalDetail(id,false);
                }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
            },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));
            d.show();
        }).setNegativeButton("CANCEL",null).show();
    }

    String csvCell(String value){
        if(value==null)value="";
        return "\""+value.replace("\"","\"\"").replace("\n"," ").replace("\r"," ")+"\"";
    }
    String stageLabel(int stage){
        if(stage>=4)return "Final update received";
        if(stage==3)return "Given to 3rd level";
        if(stage==2)return "Given to 2nd level";
        return "First level";
    }
    void exportApprovals(String mode){
        exportMode=mode;
        String name="trackrb_"+mode+"_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.getDefault()).format(new Date())+".csv";
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("text/csv"); i.putExtra(Intent.EXTRA_TITLE,name); i.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(i,exportRequest);}catch(Exception e){Toast.makeText(this,"Export not available",Toast.LENGTH_SHORT).show();}
    }

    void showApprovalDetail(long id, boolean closedView){
        JSONObject found=null;
        JSONArray a=arr("approvals");
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optLong("id")==id){found=o;break;}}
        if(found==null)return;
        Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(16),dp(18),dp(12));box.setBackgroundColor(Color.WHITE);
        TextView h=tv(blank(found.optString("subject")),20);h.setTypeface(null,Typeface.BOLD);box.addView(h);
        box.addView(tv("From: "+blank(found.optString("from"))+"\nReceived: "+blank(found.optString("received"))+"\nDue: "+(found.optString("due").isEmpty()?"Not set":found.optString("due")),15));
        box.addView(tv("Current stage: "+stageLabel(found.optInt("stage",1)),14));
        addMovementHistoryTable(box,found);
        String scan=found.optString("scan");
        Button scanBtn=btn("VIEW FRONT SCAN");scanBtn.setEnabled(!scan.isEmpty());scanBtn.setOnClickListener(v->openAttachment(scan));box.addView(scanBtn);
        if(!closedView){
            int stage=found.optInt("stage",1);
            if(found.optBoolean("returned")){
                Button receivedBack=btn("RECEIVED BACK NOW");
                receivedBack.setOnClickListener(v->{d.dismiss();receiveBack(id);});
                box.addView(receivedBack);
            }else{
                Button returned=btn("MARK RETURNED");
                returned.setOnClickListener(v->{d.dismiss();markReturned(id);});
                box.addView(returned);
            }
            if(stage<2){
                Button b2=btn("GIVEN TO 2ND LEVEL (OPTIONAL)");
                b2.setOnClickListener(v->{d.dismiss();advanceApproval(id,2);});box.addView(b2);
                Button direct3=btn("GIVEN DIRECTLY TO 3RD LEVEL");
                direct3.setOnClickListener(v->{d.dismiss();advanceApproval(id,3);});box.addView(direct3);
            }
            if(stage==2){Button b3=btn("GIVEN TO 3RD LEVEL");b3.setOnClickListener(v->{d.dismiss();advanceApproval(id,3);});box.addView(b3);}
            if(stage>=3 && stage<4){Button bf=btn("RECORD FINAL UPDATE RECEIVED");bf.setOnClickListener(v->{d.dismiss();recordFinalUpdate(id);});box.addView(bf);}
        }
        if(closedView){
            String fin=found.optString("final");
            Button finalBtn=btn("VIEW FINAL APPROVAL COPY");finalBtn.setEnabled(!fin.trim().isEmpty());finalBtn.setOnClickListener(v->openAttachment(fin));box.addView(finalBtn);
        }else{
            Button close=btn("CLOSE + ATTACH FINAL COPY");
            close.setOnClickListener(v->{
                if(found.optInt("stage",1)<4 || found.optString("finalUpdate").trim().isEmpty() || found.optString("approvedTo").trim().isEmpty()){
                    Toast.makeText(this,"First record Final Update and Approved/Sent-to user name",Toast.LENGTH_LONG).show();
                    d.dismiss(); recordFinalUpdate(id);
                }else{
                    d.dismiss(); closeApproval(id);
                }
            });
            box.addView(close);
        }
        Button cancel=btn("CLOSE");cancel.setOnClickListener(v->d.dismiss());box.addView(cancel);
        d.setContentView(box);d.show();
        if(d.getWindow()!=null){d.getWindow().setLayout(-1,-2);}
    }

    void showApprovalList(boolean wantClosed){
        base(wantClosed?"Closed Approvals":"Pending Approvals");

        EditText search=edit("Search subject, department, received or due date...");
        search.setSingleLine(true);
        search.setTextSize(14);
        content.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));

        TextView info=tv("TABLE VIEW  •  Tap any row for details & attachments",13);
        info.setTextColor(muted);
        content.addView(info);

        HorizontalScrollView hsv=new HorizontalScrollView(this);
        hsv.setFillViewport(false);
        TableLayout table=new TableLayout(this);
        table.setStretchAllColumns(false);
        table.setShrinkAllColumns(false);
        table.setBackgroundColor(Color.WHITE);

        TableRow header=new TableRow(this);
        String[] heads={"S.NO","SUBJECT / DESCRIPTION","FROM","RECEIVED","DUE","STATUS"};
        int[] widths={55,230,140,145,120,105};
        for(int i=0;i<heads.length;i++) header.addView(cell(heads[i],true),new TableRow.LayoutParams(dp(widths[i]),dp(52)));
        table.addView(header,new TableLayout.LayoutParams(-2,-2));
        hsv.addView(table);
        content.addView(hsv,new LinearLayout.LayoutParams(-1,0,1));

        Runnable[] refresh=new Runnable[1];
        refresh[0]=()->{
            while(table.getChildCount()>1)table.removeViewAt(1);
            String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            JSONArray a=arr("approvals");
            int shown=0,serial=1;
            for(int i=a.length()-1;i>=0;i--){
                JSONObject o=a.optJSONObject(i);
                if(o==null||o.optBoolean("closed")!=wantClosed)continue;
                String hay=(o.optString("subject")+" "+o.optString("from")+" "+o.optString("received")+" "+o.optString("due")).toLowerCase(Locale.ROOT);
                if(!q.isEmpty()&&!hay.contains(q))continue;
                shown++;addApprovalTableRow(table,o,wantClosed,serial++);
            }
            if(shown==0){
                TableRow empty=new TableRow(this);
                TextView e=cell(q.isEmpty()?"No records here.":"No matching records.",false);
                empty.addView(e,new TableRow.LayoutParams(dp(795),dp(58)));
                table.addView(empty,new TableLayout.LayoutParams(-2,-2));
            }
        };
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){refresh[0].run();}
            public void afterTextChanged(Editable e){}
        });
        refresh[0].run();

        if(wantClosed){
            Button export=btn("EXPORT APPROVED LIST TO EXCEL");
            export.setOnClickListener(v->exportApprovals("approved")); content.addView(export);
        }else{
            Button exportPending=btn("EXPORT PENDING LIST TO EXCEL");
            exportPending.setOnClickListener(v->exportApprovals("pending")); content.addView(exportPending);
            Button exportLevel2=btn("EXPORT 2ND LEVEL PENDING TO EXCEL");
            exportLevel2.setOnClickListener(v->exportApprovals("level2")); content.addView(exportLevel2);
        }
        Button back=btn("←  Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();
    }

    void closeApproval(long id){
        finalApprovalId=id;
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},cameraRequest);return;
        }
        try{
            File dir=new File(getFilesDir(),"images");dir.mkdirs();
            File f=new File(dir,"final_"+System.currentTimeMillis()+".jpg");
            finalPhotoFilePath=f.getAbsolutePath();finalPhotoUri=FileProvider.getUriForFile(this,"com.trackrb.app.fileprovider",f);
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT,finalPhotoUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i,finalRequest);
        }catch(Exception e){Toast.makeText(this,"Camera could not open: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    void markClosed(long id,String finalUri){try{JSONArray a=arr("approvals");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id){a.getJSONObject(i).put("closed",true);a.getJSONObject(i).put("final",finalUri==null?"":finalUri);a.getJSONObject(i).put("closedAt",now());break;}save("approvals",a);showApprovalList(false);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}

    void showTodo(){
        base("Today's To-Do");EditText task=edit("What needs to be done?");EditText who=edit("Whom / person");TextView when=tv("Due: Not selected",15);String[] whenValue={""};Button pick=btn("SELECT DATE & TIME");pick.setOnClickListener(v->pickDateTime(when,whenValue));content.addView(task);content.addView(who);content.addView(pick);content.addView(when);
        Button add=btn("SAVE TO-DO");add.setOnClickListener(v->{if(task.getText().toString().trim().isEmpty()){task.setError("Required");return;}try{JSONArray a=arr("todos");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("task",task.getText().toString().trim());o.put("who",who.getText().toString().trim());o.put("when",whenValue[0]);o.put("created",now());o.put("done",false);o.put("doneAt","");a.put(o);save("todos",a);showTodoList();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});content.addView(add);Button list=btn("VIEW TO-DO LIST / HISTORY");list.setOnClickListener(v->showTodoList());content.addView(list);nav();
    }
    void showTodoList(){
        base("To-Do List / History");JSONArray a=arr("todos");int n=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;n++;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundColor(Color.WHITE);c.addView(tv((o.optBoolean("done")?"✓  ":"•  ")+o.optString("task"),18));c.addView(tv("Whom: "+blank(o.optString("who"))+"\nDue: "+blank(o.optString("when"))+"\nCreated: "+o.optString("created")+(o.optBoolean("done")?"\nClosed: "+blank(o.optString("doneAt")):""),14));if(!o.optBoolean("done")){long id=o.optLong("id");Button d=btn("MARK CLOSED");d.setOnClickListener(v->todoDone(id));c.addView(d);}content.addView(c,new LinearLayout.LayoutParams(-1,-2));Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(9)));}if(n==0)content.addView(tv("No To-Do records.",17));Button back=btn("←  Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();
    }
    void todoDone(long id){try{JSONArray a=arr("todos");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id){a.getJSONObject(i).put("done",true);a.getJSONObject(i).put("doneAt",now());}save("todos",a);showTodoList();}catch(Exception e){}}

    void showFollowups(){
        base("Follow-ups");EditText what=edit("What to follow up?");EditText whom=edit("Whom to ask?");TextView date=tv("Due: Not selected",15);String[] dateValue={""};Button pick=btn("SELECT DATE & TIME");pick.setOnClickListener(v->pickDateTime(date,dateValue));content.addView(what);content.addView(whom);content.addView(pick);content.addView(date);
        Button add=btn("SAVE FOLLOW-UP");add.setOnClickListener(v->{if(what.getText().toString().trim().isEmpty()){what.setError("Required");return;}try{JSONArray a=arr("followups");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("what",what.getText().toString().trim());o.put("whom",whom.getText().toString().trim());o.put("date",dateValue[0]);o.put("created",now());o.put("done",false);o.put("doneAt","");a.put(o);save("followups",a);showFollowupList();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});content.addView(add);Button list=btn("VIEW FOLLOW-UP HISTORY");list.setOnClickListener(v->showFollowupList());content.addView(list);nav();
    }
    void showFollowupList(){
        base("Follow-up History");JSONArray a=arr("followups");int n=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;n++;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundColor(Color.WHITE);c.addView(tv((o.optBoolean("done")?"✓  ":"•  ")+o.optString("what"),18));c.addView(tv("Whom: "+blank(o.optString("whom"))+"\nDue: "+blank(o.optString("date"))+"\nCreated: "+o.optString("created")+(o.optBoolean("done")?"\nCompleted: "+blank(o.optString("doneAt")):""),14));if(!o.optBoolean("done")){long id=o.optLong("id");Button d=btn("MARK DONE");d.setOnClickListener(v->followDone(id));c.addView(d);}content.addView(c,new LinearLayout.LayoutParams(-1,-2));Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(9)));}if(n==0)content.addView(tv("No follow-up records.",17));Button back=btn("←  Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();
    }
    void followDone(long id){try{JSONArray a=arr("followups");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id){a.getJSONObject(i).put("done",true);a.getJSONObject(i).put("doneAt",now());}save("followups",a);showFollowupList();}catch(Exception e){}}
    String capFirst(String s){if(s==null||s.trim().isEmpty())return s;String t=s.trim();return t.substring(0,1).toUpperCase(Locale.getDefault())+t.substring(1);}
    String now(){return new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date());}
}
