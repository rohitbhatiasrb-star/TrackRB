package com.trackrb.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; TextView title; SharedPreferences sp; Uri photoUri;
    final int CAMERA=101, NOTIF=102;
    int blue=Color.rgb(25,118,210), red=Color.rgb(211,47,47), green=Color.rgb(46,125,50);
    public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("trackrb",0); requestPerms(); showDashboard();}
    void requestPerms(){ if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF); }
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(24,18,24,18);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
    void base(String name){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(248,249,250));
      title=tv("TrackRB\n"+name,24);title.setTextColor(Color.WHITE);title.setBackgroundColor(blue);root.addView(title,new LinearLayout.LayoutParams(-1,100));
      content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root); }
    void nav(){LinearLayout n=new LinearLayout(this); String[] a={"Dashboard","New Approval","To-Do","Follow-ups"}; for(String x:a){Button b=btn(x);b.setOnClickListener(v->{if(x.equals("Dashboard"))showDashboard();else if(x.equals("New Approval"))showApproval();else if(x.equals("To-Do"))showTodo();else showFollowups();});n.addView(b,new LinearLayout.LayoutParams(0,60,1));}root.addView(n);}
    int count(String key){return sp.getInt(key,0);}
    void showDashboard(){base("Dashboard");int pending=count("pending"), todo=count("todo"), closed=count("closed"), follow=count("follow");
      content.addView(tv("APPROVAL PENDENCY",18)); content.addView(tv("Pending approvals: "+pending,22));content.addView(tv("Overdue / due follow-ups: "+follow,20));content.addView(tv("Today's To-Do: "+todo,20));content.addView(tv("Closed approvals: "+closed,20));
      Button b=btn("＋ Add New Approval");b.setOnClickListener(v->showApproval());content.addView(b); Button t=btn("＋ Add Today's To-Do");t.setOnClickListener(v->showTodo());content.addView(t);nav(); }
    void showApproval(){base("New Approval");EditText subject=new EditText(this);subject.setHint("Approval subject / description");EditText from=new EditText(this);from.setHint("Received from / department");EditText due=new EditText(this);due.setHint("Due date (dd-MM-yyyy)");
      TextView stamp=tv("Entry time: "+now(),16);content.addView(stamp);content.addView(subject);content.addView(from);content.addView(due);
      Button cam=btn("📷 Scan Front Paper");cam.setOnClickListener(v->camera());content.addView(cam);TextView photo=tv("No scan attached",15);content.addView(photo);
      Button save=btn("SAVE APPROVAL");save.setOnClickListener(v->{if(subject.getText().toString().trim().isEmpty()){subject.setError("Required");return;}sp.edit().putInt("pending",count("pending")+1).apply();Toast.makeText(this,"Approval saved",Toast.LENGTH_SHORT).show();showDashboard();});content.addView(save);Button close=btn("Close an Approval / Attach Final Copy");close.setOnClickListener(v->{if(count("pending")>0){sp.edit().putInt("pending",count("pending")-1).putInt("closed",count("closed")+1).apply();Toast.makeText(this,"Approval closed. Attach final copy in your record.",Toast.LENGTH_LONG).show();showDashboard();}else Toast.makeText(this,"No pending approval",Toast.LENGTH_SHORT).show();});content.addView(close);nav();}
    void camera(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAMERA);return;}try{File dir=new File(getFilesDir(),"images");dir.mkdirs();File f=new File(dir,"approval_"+System.currentTimeMillis()+".jpg");photoUri=FileProvider.getUriForFile(this,"com.trackrb.app.fileprovider",f);Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,202);}catch(Exception e){Toast.makeText(this,"Camera could not open: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==CAMERA&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)camera();}
    void showTodo(){base("Today's To-Do");EditText task=new EditText(this);task.setHint("What needs to be done?");EditText who=new EditText(this);who.setHint("Whom / person");EditText when=new EditText(this);when.setHint("Follow-up / due date & time");content.addView(task);content.addView(who);content.addView(when);Button add=btn("SAVE TO-DO");add.setOnClickListener(v->{if(task.getText().toString().trim().isEmpty()){task.setError("Required");return;}sp.edit().putInt("todo",count("todo")+1).apply();Toast.makeText(this,"To-Do saved and traceable",Toast.LENGTH_SHORT).show();showTodo();});content.addView(add);Button done=btn("Mark one To-Do CLOSED");done.setOnClickListener(v->{if(count("todo")>0)sp.edit().putInt("todo",count("todo")-1).apply();showTodo();});content.addView(done);content.addView(tv("History is retained in the app data counters; future version can show full item-wise history.",14));nav();}
    void showFollowups(){base("Follow-ups");EditText what=new EditText(this);what.setHint("What to follow up?");EditText whom=new EditText(this);whom.setHint("Whom to ask?");EditText date=new EditText(this);date.setHint("Follow-up date & time");content.addView(what);content.addView(whom);content.addView(date);Button add=btn("SAVE FOLLOW-UP");add.setOnClickListener(v->{if(what.getText().toString().trim().isEmpty()){what.setError("Required");return;}sp.edit().putInt("follow",count("follow")+1).apply();Toast.makeText(this,"Follow-up added",Toast.LENGTH_SHORT).show();showDashboard();});content.addView(add);Button done=btn("Mark one FOLLOW-UP DONE");done.setOnClickListener(v->{if(count("follow")>0)sp.edit().putInt("follow",count("follow")-1).apply();showFollowups();});content.addView(done);nav();}
    String now(){return new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date());}
}
