# TrackRB Android APK

Upload the project files to the root of the GitHub repository. The workflow in `.github/workflows/build-apk.yml` builds a debug APK.

Run: GitHub → Actions → Build APK → Run workflow.
