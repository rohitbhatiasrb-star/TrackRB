package com.trackrb.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; TextView title; SharedPreferences sp; float den;
    Uri photoUri; int cameraRequest=101, finalRequest=102; long finalApprovalId;
    int blue=Color.rgb(25,118,210), dark=Color.rgb(55,55,55), bg=Color.rgb(248,249,250);
    public void onCreate(Bundle b){super.onCreate(b); den=getResources().getDisplayMetrics().density; sp=getSharedPreferences("trackrb",0); requestNotification(); showDashboard();}
    void requestNotification(){ if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},900); }
    int dp(int v){return (int)(v*den+0.5f);}
    TextView tv(String s,int size){TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark); t.setPadding(dp(16),dp(12),dp(16),dp(12)); t.setGravity(Gravity.CENTER_VERTICAL); return t;}
    Button btn(String s){Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setMinHeight(dp(48)); b.setAllCaps(false); return b;}
    void base(String name){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
      title=tv("TrackRB  •  "+name,21);title.setTextColor(Color.WHITE);title.setBackgroundColor(blue);title.setGravity(Gravity.CENTER_VERTICAL);root.addView(title,new LinearLayout.LayoutParams(-1,dp(58)));
      ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void nav(){LinearLayout n=new LinearLayout(this);String[] a={"Dashboard","New Approval","To-Do","Follow-ups"};for(String x:a){Button b=btn(x);b.setOnClickListener(v->{if(x.equals("Dashboard"))showDashboard();else if(x.equals("New Approval"))showApproval();else if(x.equals("To-Do"))showTodo();else showFollowups();});n.addView(b,new LinearLayout.LayoutParams(0,dp(54),1));}root.addView(n);}
    JSONArray arr(String key){try{return new JSONArray(sp.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
    void save(String key,JSONArray a){sp.edit().putString(key,a.toString()).apply();}
    int pending(){JSONArray a=arr("approvals");int n=0;for(int i=0;i<a.length();i++)if(!a.optJSONObject(i).optBoolean("closed"))n++;return n;}
    int closed(){JSONArray a=arr("approvals");int n=0;for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optBoolean("closed"))n++;return n;}
    int todoOpen(){JSONArray a=arr("todos");int n=0;for(int i=0;i<a.length();i++)if(!a.optJSONObject(i).optBoolean("done"))n++;return n;}
    int followDue(){JSONArray a=arr("followups");int n=0;for(int i=0;i<a.length();i++)if(!a.optJSONObject(i).optBoolean("done"))n++;return n;}
    TextView clickableStat(String text,View.OnClickListener l){TextView t=tv(text,22);t.setOnClickListener(l);t.setBackgroundColor(Color.rgb(235,235,235));t.setPadding(dp(18),dp(16),dp(18),dp(16));t.setTextSize(18);t.setGravity(Gravity.CENTER_VERTICAL);content.addView(t,new LinearLayout.LayoutParams(-1,dp(64)));return t;}
    void showDashboard(){base("Dashboard");content.addView(tv("APPROVAL PENDENCY",19));content.addView(tv("Tap any counter below to open its list.",14));
      clickableStat("Pending approvals: "+pending(),v->showApprovalList(false));
      clickableStat("Overdue / due follow-ups: "+followDue(),v->showFollowupList());
      clickableStat("Today's To-Do: "+todoOpen(),v->showTodoList());
      clickableStat("Closed approvals: "+closed(),v->showApprovalList(true));
      Button b=btn("＋ ADD NEW APPROVAL");b.setOnClickListener(v->showApproval());content.addView(b);
      Button t=btn("＋ ADD TODAY'S TO-DO");t.setOnClickListener(v->showTodo());content.addView(t);nav();}
    void showApproval(){base("New Approval");EditText subject=new EditText(this);subject.setHint("Approval subject / description");EditText from=new EditText(this);from.setHint("Received from / department");EditText due=new EditText(this);due.setHint("Due date (dd-MM-yyyy)");
      content.addView(tv("Received automatically: "+now(),16));content.addView(subject);content.addView(from);content.addView(due);
      TextView photo=tv("No scan attached",15);Button cam=btn("📷 SCAN FRONT PAPER");cam.setOnClickListener(v->camera(photo));content.addView(cam);content.addView(photo);
      Button save=btn("SAVE APPROVAL");save.setOnClickListener(v->{if(subject.getText().toString().trim().isEmpty()){subject.setError("Required");return;}try{JSONArray a=arr("approvals");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("subject",subject.getText().toString().trim());o.put("from",from.getText().toString().trim());o.put("due",due.getText().toString().trim());o.put("received",now());o.put("scan",photoUri==null?"":photoUri.toString());o.put("closed",false);o.put("final"," ");a.put(o);save("approvals",a);photoUri=null;Toast.makeText(this,"Approval saved",Toast.LENGTH_SHORT).show();showApprovalList(false);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});content.addView(save);nav();}
    void camera(TextView label){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},cameraRequest);return;}try{File dir=new File(getFilesDir(),"images");dir.mkdirs();File f=new File(dir,"approval_"+System.currentTimeMillis()+".jpg");photoUri=FileProvider.getUriForFile(this,"com.trackrb.app.fileprovider",f);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,200);label.setText("Camera opened — scan will be attached after capture");}catch(Exception e){Toast.makeText(this,"Camera could not open: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    public void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==200 && c==RESULT_OK){Toast.makeText(this,"Scan captured",Toast.LENGTH_SHORT).show();}else if(r==finalRequest&&c==RESULT_OK&&d!=null&&d.getData()!=null){try{getContentResolver().takePersistableUriPermission(d.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION);JSONArray a=arr("approvals");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optLong("id")==finalApprovalId){o.put("final",d.getData().toString());break;}}save("approvals",a);showApprovalList(false);}catch(Exception e){Toast.makeText(this,"Could not attach copy",Toast.LENGTH_LONG).show();}}}
    public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==cameraRequest&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED){} }
    void showApprovalList(boolean wantClosed){base(wantClosed?"Closed Approvals":"Pending Approvals");JSONArray a=arr("approvals");int shown=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||o.optBoolean("closed")!=wantClosed)continue;shown++;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(8,10,8,10);card.setBackgroundColor(Color.WHITE);card.addView(tv(o.optString("subject"),20));card.addView(tv("Received: "+o.optString("received")+"\nFrom: "+o.optString("from")+"\nDue: "+o.optString("due"),15));if(!o.optString("scan").isEmpty())card.addView(tv("📷 Front paper scan attached",14));if(wantClosed){if(!o.optString("final").trim().isEmpty())card.addView(tv("📎 Final approval copy attached",14));}else{Button close=btn("CLOSE + ATTACH FINAL COPY");long id=o.optLong("id");close.setOnClickListener(v->closeApproval(id));card.addView(close);}content.addView(card,new LinearLayout.LayoutParams(-1,-2));Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,12));}if(shown==0)content.addView(tv("No records here.",18));Button back=btn("← Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();}
    void closeApproval(long id){finalApprovalId=id;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);i.addCategory(Intent.CATEGORY_OPENABLE);try{startActivityForResult(i,finalRequest);}catch(Exception e){markClosed(id,"");}}
    void markClosed(long id,String finalUri){try{JSONArray a=arr("approvals");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optLong("id")==id){o.put("closed",true);if(finalUri!=null&&!finalUri.isEmpty())o.put("final",finalUri);break;}}save("approvals",a);showApprovalList(false);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
    void showTodo(){base("Today's To-Do");EditText task=new EditText(this);task.setHint("What needs to be done?");EditText who=new EditText(this);who.setHint("Whom / person");EditText when=new EditText(this);when.setHint("Due date & time");content.addView(task);content.addView(who);content.addView(when);Button add=btn("SAVE TO-DO");add.setOnClickListener(v->{if(task.getText().toString().trim().isEmpty()){task.setError("Required");return;}try{JSONArray a=arr("todos");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("task",task.getText().toString().trim());o.put("who",who.getText().toString().trim());o.put("when",when.getText().toString().trim());o.put("created",now());o.put("done",false);a.put(o);save("todos",a);showTodoList();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});content.addView(add);Button list=btn("VIEW TO-DO LIST / HISTORY");list.setOnClickListener(v->showTodoList());content.addView(list);nav();}
    void showTodoList(){base("To-Do List / History");JSONArray a=arr("todos");for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.addView(tv((o.optBoolean("done")?"✓ ":"• ")+o.optString("task"),19));c.addView(tv("Whom: "+o.optString("who")+"\nDue: "+o.optString("when")+"\nCreated: "+o.optString("created"),14));if(!o.optBoolean("done")){long id=o.optLong("id");Button d=btn("MARK CLOSED");d.setOnClickListener(v->todoDone(id));c.addView(d);}content.addView(c);}Button back=btn("← Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();}
    void todoDone(long id){try{JSONArray a=arr("todos");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id)a.getJSONObject(i).put("done",true);save("todos",a);showTodoList();}catch(Exception e){}}
    void showFollowups(){base("Follow-ups");EditText what=new EditText(this);what.setHint("What to follow up?");EditText whom=new EditText(this);whom.setHint("Whom to ask?");EditText date=new EditText(this);date.setHint("Follow-up date & time");content.addView(what);content.addView(whom);content.addView(date);Button add=btn("SAVE FOLLOW-UP");add.setOnClickListener(v->{if(what.getText().toString().trim().isEmpty()){what.setError("Required");return;}try{JSONArray a=arr("followups");JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("what",what.getText().toString().trim());o.put("whom",whom.getText().toString().trim());o.put("date",date.getText().toString().trim());o.put("created",now());o.put("done",false);a.put(o);save("followups",a);showFollowupList();}catch(Exception e){}});content.addView(add);Button list=btn("VIEW FOLLOW-UP HISTORY");list.setOnClickListener(v->showFollowupList());content.addView(list);nav();}
    void showFollowupList(){base("Follow-up History");JSONArray a=arr("followups");for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.addView(tv((o.optBoolean("done")?"✓ ":"• ")+o.optString("what"),19));c.addView(tv("Whom: "+o.optString("whom")+"\nDue: "+o.optString("date")+"\nCreated: "+o.optString("created"),14));if(!o.optBoolean("done")){long id=o.optLong("id");Button d=btn("MARK DONE");d.setOnClickListener(v->followDone(id));c.addView(d);}content.addView(c);}Button back=btn("← Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);nav();}
    void followDone(long id){try{JSONArray a=arr("followups");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optLong("id")==id)a.getJSONObject(i).put("done",true);save("followups",a);showFollowupList();}catch(Exception e){}}
    String now(){return new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date());}
}
