# Free APK Build with GitHub Actions

1. Create a GitHub repository.
2. Upload/extract all files from this project into the repository root.
3. Open the **Actions** tab.
4. Select **Build APK**.
5. Tap **Run workflow**.
6. When the workflow finishes, open the run and download the artifact named:
   `ApprovalActionTracker-APK`
7. Extract the downloaded artifact and install the APK on Android.

Notes:
- This workflow builds a release APK in GitHub's runner.
- No paid APK-builder service is required.
- GitHub Actions availability/minutes depend on the repository/account plan.
