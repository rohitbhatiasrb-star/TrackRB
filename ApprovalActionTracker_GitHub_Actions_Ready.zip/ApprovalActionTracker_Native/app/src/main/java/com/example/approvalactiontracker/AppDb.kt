package com.example.approvalactiontracker
import android.content.Context
import androidx.room.*
@Dao interface ApprovalDao {
 @Query("SELECT * FROM Approval ORDER BY receivedAt DESC") fun all():List<Approval>
 @Insert fun insert(x:Approval)
 @Query("UPDATE Approval SET closed=1, finalUri=:uri WHERE id=:id") fun close(id:Int,uri:String?)
}
@Dao interface TodoDao {
 @Query("SELECT * FROM Todo ORDER BY createdAt DESC") fun all():List<Todo>
 @Insert fun insert(x:Todo)
 @Query("UPDATE Todo SET status='Closed',closedAt=:t WHERE id=:id") fun close(id:Int,t:Long)
}
@Dao interface FollowDao {
 @Query("SELECT * FROM FollowUp ORDER BY createdAt DESC") fun all():List<FollowUp>
 @Insert fun insert(x:FollowUp)
 @Query("UPDATE FollowUp SET status='Closed',closedAt=:t WHERE id=:id") fun close(id:Int,t:Long)
}
@Database(entities=[Approval::class,Todo::class,FollowUp::class],version=1)
abstract class AppDb:RoomDatabase(){
 abstract fun approvalDao():ApprovalDao; abstract fun todoDao():TodoDao; abstract fun followDao():FollowDao
 companion object { @Volatile private var INSTANCE:AppDb?=null
 fun get(c:Context)=INSTANCE?:synchronized(this){INSTANCE?:Room.databaseBuilder(c,AppDb::class.java,"tracker.db").allowMainThreadQueries().build().also{INSTANCE=it}}
 }
}
