package com.example.approvalactiontracker

import android.app.*
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:AppCompatActivity(){
 lateinit var db:AppDb; lateinit var root:LinearLayout
 val pickApproval=registerForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{approvalUri=it}}
 var approvalUri:Uri?=null
 val pickFinal=registerForActivityResult(ActivityResultContracts.OpenDocument()){u-> if(u!=null && closeApprovalId!=null){db.approvalDao().close(closeApprovalId!!,u.toString());closeApprovalId=null;dashboard()}}
 var closeApprovalId:Int?=null

 override fun onCreate(b:Bundle?){super.onCreate(b);db=AppDb.get(this); requestCamera(); dashboard()}
 fun requestCamera(){if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission("android.permission.CAMERA")!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf("android.permission.CAMERA"),10)}
 fun base(title:String):LinearLayout{
  root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);setBackgroundColor(Color.rgb(246,249,249))}
  val h=TextView(this).apply{text=title;textSize=24f;setTextColor(Color.rgb(7,125,115));setPadding(0,8,0,18)}
  root.addView(h); val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  listOf("Dashboard","Approval","To-Do","Follow-up").forEachIndexed{_,s->bar.addView(Button(this).apply{text=s;setOnClickListener{when(s){"Dashboard"->dashboard();"Approval"->approvalForm();"To-Do"->todoForm();"Follow-up"->followForm()}}},LinearLayout.LayoutParams(0,60,1f))}
  root.addView(bar);setContentView(root);return root
 }
 fun tv(s:String,bold:Boolean=false):TextView=TextView(this).apply{text=s;textSize=16f;setPadding(0,10,0,10);if(bold) setTypeface(null,1)}
 fun inp(hint:String):EditText=EditText(this).apply{this.hint=hint;setPadding(8,4,8,4)}
 fun add(v:View){root.addView(v,LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT))}
 fun dashboard(){base("Approval Action Tracker");val a=db.approvalDao().all();val t=db.todoDao().all();val f=db.followDao().all()
  add(tv("Pending Approvals: ${a.count{!it.closed}}",true));add(tv("Today's / Pending To-Do: ${t.count{it.status!="Closed"}}",true));add(tv("Pending Follow-ups: ${f.count{it.status!="Closed"}}",true));add(tv("Closed Approvals: ${a.count{it.closed}}",true))
  add(tv("Recent approvals",true));a.take(5).forEach{add(tv("${it.subject} — ${if(it.closed)"Closed" else "Pending"}"))}
 }
 fun approvalForm(){base("New Approval");val s=inp("Subject *");val d=inp("Department");val am=inp("Amount");val fr=inp("Received from");val due=inp("Due date (yyyy-MM-dd)");val p=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Normal","High","Urgent"))}
  listOf(s,d,am,fr,due).forEach{add(it)};add(tv("Scan paper",true));add(Button(this).apply{text="📷 Capture / Choose scan";setOnClickListener{pickApproval.launch(arrayOf("image/*","application/pdf"))}})
  add(p);add(Button(this).apply{text="Save Approval";setOnClickListener{if(s.text.toString().trim().isEmpty()){s.error="Required";return@setOnClickListener};db.approvalDao().insert(Approval(subject=s.text.toString(),department=d.text.toString(),amount=am.text.toString(),fromPerson=fr.text.toString(),dueAt=parseDate(due.text.toString()),priority=p.selectedItem.toString(),scanUri=approvalUri?.toString()));approvalUri=null;dashboard()}})
 }
 fun todoForm(){base("Today's To-Do");val task=inp("What needs to be done? *");val person=inp("Whom to ask / responsible person");val due=inp("Due date (yyyy-MM-dd)");val pri=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Normal","High","Urgent"))};val notes=inp("Notes");listOf(task,person,due,pri,notes).forEach{add(it)};add(Button(this).apply{text="Add To-Do";setOnClickListener{if(task.text.isEmpty()){task.error="Required";return@setOnClickListener};db.todoDao().insert(Todo(task=task.text.toString(),person=person.text.toString(),dueAt=parseDate(due.text.toString()),priority=pri.selectedItem.toString(),notes=notes.text.toString()));dashboard()}})
  db.todoDao().all().forEach{if(it.status!="Closed"){add(tv("• ${it.task} — ${it.person} — ${fmt(it.dueAt)}"));add(Button(this).apply{text="Mark Closed";setOnClickListener{db.todoDao().close(it.id,System.currentTimeMillis());todoForm()}})}}
 }
 fun followForm(){base("Follow-ups");val sub=inp("For approval / subject");val what=inp("What to do? *");val who=inp("Whom to ask?");val due=inp("Follow-up date (yyyy-MM-dd)");listOf(sub,what,who,due).forEach{add(it)};add(Button(this).apply{text="Add Follow-up";setOnClickListener{if(what.text.isEmpty()){what.error="Required";return@setOnClickListener};db.followDao().insert(FollowUp(subject=sub.text.toString(),what=what.text.toString(),who=who.text.toString(),dueAt=parseDate(due.text.toString())));dashboard()}})
  db.followDao().all().forEach{if(it.status!="Closed"){add(tv("• ${it.what} — ${it.who} — ${fmt(it.dueAt)}"));add(Button(this).apply{text="Mark Done";setOnClickListener{db.followDao().close(it.id,System.currentTimeMillis());followForm()}})}}
 }
 fun parseDate(s:String):Long?=try{SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s)?.time}catch(_:Exception){null}
 fun fmt(t:Long?):String=if(t==null)"-" else SimpleDateFormat("dd MMM yyyy",Locale.US).format(Date(t))
}
