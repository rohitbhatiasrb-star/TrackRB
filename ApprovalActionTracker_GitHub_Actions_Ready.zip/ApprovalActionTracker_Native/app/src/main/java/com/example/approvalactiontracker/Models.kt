package com.example.approvalactiontracker
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity data class Approval(
    @PrimaryKey(autoGenerate=true) val id:Int=0,
    val subject:String, val department:String, val amount:String, val fromPerson:String,
    val receivedAt:Long=System.currentTimeMillis(), val dueAt:Long?, val priority:String,
    val scanUri:String?=null, val closed:Boolean=false, val finalUri:String?=null
)
@Entity data class Todo(
    @PrimaryKey(autoGenerate=true) val id:Int=0, val task:String, val person:String,
    val dueAt:Long?, val priority:String, val notes:String, val status:String="Pending",
    val createdAt:Long=System.currentTimeMillis(), val closedAt:Long?=null
)
@Entity data class FollowUp(
    @PrimaryKey(autoGenerate=true) val id:Int=0, val subject:String, val what:String,
    val who:String, val dueAt:Long?, val status:String="Pending",
    val createdAt:Long=System.currentTimeMillis(), val closedAt:Long?=null
)
