# Approval Action Tracker — Native Android Project

This is a native Android/Kotlin starter with:
- Room local database for Approvals, Today's To-Do and Follow-ups
- Approval scan/final-copy file attachment
- Android camera permission and capture-capable file picker
- Pending/closed status
- Traceable creation/closure timestamps in the database

Important:
- This project must be compiled with Android Studio/Gradle or an Android build service to produce an APK.
- This environment does not have a configured Android SDK/signing environment, so an APK is not included.
- The current camera action uses Android's document/image picker with camera capture capability; a full auto-edge document scanner/OCR requires adding ML Kit/CameraX scanning.


Build note: this ZIP is intended for a cloud source-build service. A Gradle wrapper JAR is not bundled; Code2Native documents that it can synthesize a missing wrapper for source builds.
